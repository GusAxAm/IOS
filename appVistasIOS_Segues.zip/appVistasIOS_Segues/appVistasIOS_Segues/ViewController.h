//
//  ViewController.h
//  appVistasIOS_Segues
//
//  Created by Martin Oswaldo Valdes on 28/10/22.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

