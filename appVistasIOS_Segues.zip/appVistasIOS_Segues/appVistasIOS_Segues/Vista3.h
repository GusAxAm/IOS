//
//  Vista3.h
//  appVistasIOS_Segues
//
//  Created by Martin Oswaldo Valdes on 28/10/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Vista3 : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imagenesVehiculos;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentControl;
-(IBAction)segmentChangedValue:(UISegmentedControl *)sender;

@end

NS_ASSUME_NONNULL_END
