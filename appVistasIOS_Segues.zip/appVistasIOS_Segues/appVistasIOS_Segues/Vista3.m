//
//  Vista3.m
//  appVistasIOS_Segues
//
//  Created by Martin Oswaldo Valdes on 28/10/22.
//

#import "Vista3.h"

@interface Vista3 ()

@end

@implementation Vista3

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.imagenesVehiculos.image = [UIImage imageNamed:@"Giratina"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)segmentChangedValue:(UISegmentedControl *)sender {
    
    switch(self.segmentControl.selectedSegmentIndex) {
        
        case 0: {
            self.imagenesVehiculos.image = [UIImage imageNamed:@"Giratina"];
        } break;
            
        case 1: {
            self.imagenesVehiculos.image = [UIImage imageNamed:@"Snivy"];
        } break;
            
        case 2: {
            self.imagenesVehiculos.image = [UIImage imageNamed:@"Palkia"];
        } break;
            
        case 3: {
            self.imagenesVehiculos.image = [UIImage imageNamed:@"amugus"];
        } break;
    }
}
@end
