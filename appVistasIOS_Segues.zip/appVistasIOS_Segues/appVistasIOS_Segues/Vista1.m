//
//  Vista1.m
//  appVistasIOS_Segues
//
//  Created by Martin Oswaldo Valdes on 28/10/22.
//

#import "Vista1.h"

@interface Vista1 ()

@end

@implementation Vista1

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if([[segue identifier] isEqualToString:@"irVista2"])
    {
        Vista2 *vista2Aux = [segue destinationViewController];
        
        vista2Aux.nombre = _texto1Vista1.text;
        vista2Aux.apellido = _texto2Vista1.text;
        
    }
    
}

// Get the new view controller using [segue destinationViewController].
// Pass the selected object to the new view controller.



@end
