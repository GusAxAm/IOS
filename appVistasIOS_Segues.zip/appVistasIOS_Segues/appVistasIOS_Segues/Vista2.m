//
//  Vista2.m
//  appVistasIOS_Segues
//
//  Created by Martin Oswaldo Valdes on 28/10/22.
//

#import "Vista2.h"

@interface Vista2 ()

@end

@implementation Vista2

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _texto1Vista2.text = _nombre;
    _texto2Vista2.text = _apellido;
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
