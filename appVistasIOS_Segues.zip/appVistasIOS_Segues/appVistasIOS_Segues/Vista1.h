//
//  Vista1.h
//  appVistasIOS_Segues
//
//  Created by Martin Oswaldo Valdes on 28/10/22.
//

#import <UIKit/UIKit.h>
#import "Vista2.h"

NS_ASSUME_NONNULL_BEGIN

@interface Vista1 : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *texto1Vista1;

@property (weak, nonatomic) IBOutlet UITextField *texto2Vista1;

@end

NS_ASSUME_NONNULL_END
