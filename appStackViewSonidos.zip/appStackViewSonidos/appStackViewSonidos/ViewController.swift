//
//  ViewController.swift
//  appStackViewSonidos
//
//  Created by Usuario invitado on 01/12/22.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    var audioPlayer : AVAudioPlayer?
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func BotonesSonidos(_ sender: UIButton) {
        
        let instrumento = sender.tag
        switch instrumento
        {
        case 1:
            let pathSound = Bundle.main.path(forResource: "guitarra", ofType: "wav")!
         let url = URL (fileURLWithPath: pathSound)
            do{
                audioPlayer = try
                AVAudioPlayer(contentsOf: url)
                audioPlayer?.play()
            }
            catch{
                print("NO SE ENCONTRO EL ARCHIVO DE AUDIO")
            }
        case 2:
            let pathSound = Bundle.main.path(forResource: "teclado.wav", ofType: nil)!
         let url = URL (fileURLWithPath: pathSound)
            do{
                audioPlayer = try
                AVAudioPlayer(contentsOf: url)
                audioPlayer?.play()
            }
            catch{
                print("NO SE ENCONTRO EL ARCHIVO DE AUDIO")
            }
        case 3:
            let pathSound = Bundle.main.path(forResource: "Bateria.wav", ofType: nil)!
         let url = URL (fileURLWithPath: pathSound)
            do{
                audioPlayer = try
                AVAudioPlayer(contentsOf: url)
                audioPlayer?.play()
            }
            catch{
                print("NO SE ENCONTRO EL ARCHIVO DE AUDIO")
            }
            
        case 4:
            let pathSound = Bundle.main.path(forResource: "APPLAUSE", ofType: "WAV")!
         let url = URL (fileURLWithPath: pathSound)
            do{
                audioPlayer = try
                AVAudioPlayer(contentsOf: url)
                audioPlayer?.play()
            }
            catch{
                print("NO SE ENCONTRO EL ARCHIVO DE AUDIO")
            }
        default:
            return
        }
        
    
    }
    
    
    @IBAction func Stop(_ sender: UIButton) {
        audioPlayer?.stop()
    }
    
}

