//
//  main.swift
//  appConjuntos
//
//  Created by Usuario invitado on 16/11/22.
//

import Foundation

let conjuntoVacio:Set<Int> = []
print(conjuntoVacio)

let conjuntoVacio2:Set<Int> = Set()
print(conjuntoVacio2)

var conjuntoA: Set = [1,5,3,9]
print(conjuntoA)
for val in conjuntoA
{
    print(val,terminator: " | ")
}
print()
//var valorEliminado = conjuntoA.remove(3)
//print("Valor eliminado : ",valorEliminado as Any)
//print(conjuntoA)

print("VALOR A ELIMINAR")
var num = Int(readLine()!)
if let valor = conjuntoA.remove(num!)
{
    print("Valor eliminado : \(valor)")
    print(conjuntoA)
}
else{
    print("Elemento no encontrado")
}

conjuntoA.insert(9)
print(conjuntoA)

conjuntoA.insert(6)
print(conjuntoA)

var conjuntoB:Set<Int> = []
for _ in 1...5
{
    conjuntoB.insert(Int(arc4random_uniform(100)))
}
print("Conjunto B")
print(conjuntoB)

//Practica de fin de semana
//Apliacar las operaciones sobre conjuntos
//Tal como se leyo en wikipedia

print("UNION")
let unionAB = conjuntoA.union(conjuntoB).sorted()
print("A : \(conjuntoA) U B:\(conjuntoB) = \(unionAB)")

print("INTERSECCION")
let interseccion = conjuntoA.intersection(conjuntoB).sorted()
print("A :\(conjuntoA) ⋂ B:\(conjuntoB) = \(interseccion)")

let diferencia = conjuntoA.subtracting(conjuntoB)
print("Diferencia entre A - B",diferencia)

let diferenciaSimetrica = conjuntoA.symmetricDifference(conjuntoB)
print("Diferencia simetrica",diferenciaSimetrica)

let frutas:Set=["🍍","🍎","🥥","🍒","🍓"]
let frutasyVerduras:Set=["🍒","🌶","🍍","🍎","🍅","🥕","🥒","🧅"]
print("Frutas : ",frutas)
print("Frutas Y Verduras ",frutasyVerduras)

if frutas.isSuperset(of: frutasyVerduras)
{
    print("Fruta NO ES SUPERCONJUNTO DE FRUTAS Y VERDURAS")
}
else
{
    print("Frutas ES SUPERCONJUNTO DE FRUTAS Y VERDURAS")
}

if frutasyVerduras.isSuperset(of: frutas)
{
    print("Frutas Y Verduras ES SUPERCONJUNTO DE FRUTAS")
}
else
{
    print("Frutas Y Verduras NO ES SUPERCONJUNTO DE FRUTAS")
}
if frutas.isSubset(of: frutasyVerduras)
{
    print("Frutas ES SUBCONJUNTO DE FRUTAS Y VERDURAS")
}
else
{
    print("Frutas NO ES SUBCONJUNTO DE FRUTAS Y VERDURAS")
}

print("FRUTAS ES DISJUNTO DE FRUTAS Y VERDURAS : ",frutas.isDisjoint(with: frutasyVerduras))

let animales: Set=["🐈‍⬛","🦂","🐁","🦔"]
print(animales)
print("FRUTAS ES DISJUNTO DE ANIMALES :",animales.isDisjoint(with: frutas))
