//
//  ViewController.m
//  appJuegoCartas_1
//
//  Created by Guest User on 12/10/22.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak,nonatomic) IBOutlet UILabel *flipsLabel;
@property(nonatomic) int flipCount;
@end

@implementation ViewController


- (void) setFlipCount:(int)flipCount
{
    _flipCount = flipCount;
    self.flipsLabel.text = [NSString stringWithFormat:@"Flips: %d" , self.flipCount];
    
    NSLog(@"FlipCount cambio a : %d", flipCount);
}

- (IBAction)botonCarta:(UIButton *)sender
{
    if ([sender.currentTitle length])
    {
        [sender setBackgroundImage:[UIImage imageNamed:@"Back-card-itl_tree"] forState:UIControlStateNormal];
        [sender setTitle:@"" forState:UIControlStateNormal];
    }
    else{
        [sender setBackgroundImage:[UIImage imageNamed:@"Blank-card-hd"] forState:UIControlStateNormal];
        [sender setTitle:@"A♠︎" forState:UIControlStateNormal];
        
    }
    self.flipCount++;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
}

@end
