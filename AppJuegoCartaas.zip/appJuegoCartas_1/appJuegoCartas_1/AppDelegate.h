//
//  AppDelegate.h
//  appJuegoCartas_1
//
//  Created by Guest User on 12/10/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

