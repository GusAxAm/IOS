//
//  SceneDelegate.h
//  appJuegoCartas_1
//
//  Created by Guest User on 12/10/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

