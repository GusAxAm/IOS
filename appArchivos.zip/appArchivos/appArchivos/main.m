//
//  main.m
//  appArchivos
//
//  Created by Usuario invitado on 11/10/22.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
       
        NSFileHandle *file;
        
        NSError *error;
        
        NSMutableData *escribiendoDatosEnArchivo;
        
        NSString *path = [NSString stringWithFormat:@"/Users/Guest/Desktop/FOLDER1/FOLDER2/ArchivoPrueba1.rtf"];
        
        file = [NSFileHandle fileHandleForReadingAtPath:path];
        
        if(file == nil)
        NSLog(@"ARCHIVO NO ENCONTRADO");
        
        
        NSString *getContenidoDelArchivo =[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
        
        if(error)
        {
            NSLog(@"ERROR AL ABRIR EL ARCHIVO : %@",error.localizedDescription);
            exit(0);
        }
        
        NSLog(@"CONTENIDO DEL ARCHIVO: ");
        NSLog(@"%@",getContenidoDelArchivo);

        
    }
    return 0;
}
