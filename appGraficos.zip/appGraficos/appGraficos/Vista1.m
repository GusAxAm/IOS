//
//  Vista1.m
//  appGraficos
//
//  Created by Guest User on 17/10/22.
//

#import "Vista1.h"

@implementation Vista1

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    // Drawing code here.
    NSRect rectangulo = [self bounds];
    NSColor *color = [NSColor colorWithCalibratedRed:20/255.0 green:33/255.0 blue:61/255.0 alpha:1.0];
    [color set];
    
    [NSBezierPath fillRect:rectangulo];
    [[NSColor whiteColor] set];
    NSBezierPath *path = [[NSBezierPath alloc] init];
    [path setLineWidth:1.0];
    
    int x,midx,midy;
    float y;
    int ClientWidth = rectangulo.size.width, ClientHeight = rectangulo.size.height;
    midx = ClientWidth/2;
    midy = ClientHeight/2;
    //establecer el color del las líneas
    NSColor *randomColor = [NSColor colorWithCalibratedRed:arc4random_uniform(255)/255.0
                                                     green:arc4random_uniform(255)/255.0
                                                      blue:arc4random_uniform(255)/255.0
                                                     alpha:1.0];
    [randomColor set];
    
    NSPoint punto1;
    NSPoint punto2;
    for(x = midx-250; x <= midx; x+=10)
    {
       y = midy - (x-70) * 0.4;
        punto1.x = midx;
        punto1.y = y;
        punto2.x = x;
        punto2.y = midy;
        
        [path moveToPoint:punto1];
        [path lineToPoint:punto2];
       
    }
    for(x = midx; x <= 570; x+=10)
    {
       y = midy -100 + (x-midx) * 0.4;
        punto1.x = midx;
        punto1.y = y;
        punto2.x = x;
        punto2.y = midy;
        
        [path moveToPoint:punto1];
        [path lineToPoint:punto2];
    }
    
    for(x = midx+250; x >= midx; x-=10)
    {
       y = midy+100 - (x-midx) * 0.4;
        punto1.x = midx;
        punto1.y = y;
        punto2.x = x;
        punto2.y = midy;
        
        [path moveToPoint:punto1];
        [path lineToPoint:punto2];
    }
    for(x = midx; x >= 70; x-=10)
    {
       y = midy + 100 - (midx-x) * 0.4;
        punto1.x = midx;
        punto1.y = y;
        
        punto2.x = x;
        punto2.y = midy;
        
        [path moveToPoint:punto1];
        [path lineToPoint:punto2];
    }
   [self DibujarCurvaDeBezier];
    
}
- (NSPoint) randomPoint{
    NSPoint result;
    //obtener los extremos de la vista
    NSRect rect = [self bounds];
    result.x = rect.origin.x + random() % (int)rect.size.width;
    result.y = rect.origin.y + random() % (int)rect.size.height;
    return result;
}


-(void)DibujarCurvaDeBezier{
// The three vertices of a triangle
NSPoint p1 = NSMakePoint(100, 100);
NSPoint p2 = NSMakePoint(200, 300);
NSPoint p3 = NSMakePoint(300, 100);

// Control points
NSPoint c1 = NSMakePoint(200, 200);
NSPoint c2 = NSMakePoint(200, 0);

// Constructing the path for the triangle
NSBezierPath *bp = [NSBezierPath bezierPath];
[bp moveToPoint:p1];
[bp lineToPoint:p2];
[bp lineToPoint:p3];
[bp curveToPoint:p1 controlPoint1:c1 controlPoint2:c2];
[bp closePath];
[bp stroke];
}



@end
