//
//  AppDelegate.h
//  appGraficos
//
//  Created by Guest User on 17/10/22.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

