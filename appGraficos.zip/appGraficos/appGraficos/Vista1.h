//
//  Vista1.h
//  appGraficos
//
//  Created by Guest User on 17/10/22.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface Vista1 : NSView
- (NSPoint) randomPoint;
-(void)DibujarCurvaDeBezier;


@end

NS_ASSUME_NONNULL_END
