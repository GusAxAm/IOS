//
//  ViewController.swift
//  appSwiftIOS_1
//
//  Created by Usuario invitado on 14/11/22.
//

import UIKit

class ViewController: UIViewController {

    
    var num1:Int = 0
    var num2:Int = 0
    
    @IBOutlet weak var labelNumero: UILabel!
    
    @IBOutlet weak var Slider1: UISlider!
    
    @IBOutlet weak var Stepper1: UIStepper!
    
    @IBOutlet weak var Segmento: UISegmentedControl!
    
    @IBOutlet weak var Texto1: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        labelNumero.text = String(Slider1.value)
        //convertir()
    }
    

    @IBAction func SliderMoved(_ sender: UISlider) {
        labelNumero.text = "\(String(describing: lround(Double(sender.value))))"
        //Stepper1.value = Double(labelNumero.text!)!
        Stepper1.value = Double(sender.value)
        self.segmentedChanged(Segmento)
       
    }
    
    @IBAction func stepper1Change(_ sender: UIStepper) {
        
        labelNumero.text = "\(String(describing: lround(Double(sender.value))))"
        
        Slider1.value = Float(sender.value)
        
    }
    
    @IBAction func segmentedChanged(_ sender: UISegmentedControl) {
       // let indice = Int = Segmento.selectedSegmentIndex
        let indice : Int = sender.selectedSegmentIndex
        var num : Int = Int(labelNumero.text!)!
        
        if indice == 0{
            if num < 0{
                num *= -1
                num = 256 - num
            }
            let n = String(num,radix: 2)
            Texto1.text = n
        }
        if indice == 1
        {
            let n = String(num,radix:8)
            Texto1.text=n
            
        }
        if indice == 2
        {
            let n = String(num,radix:16)
            Texto1.text = n
        }
        
    }
    
    @IBAction func ButMenor(_ sender: UIButton) {
    }
    
    @IBAction func ButMultiplicar(_ sender: UIButton) {
        
        
    }
    
    @IBAction func Sumar(_ sender: UIButton) {
        num1 =  Int(String(labelNumero.text!))!
    }
    
    @IBAction func ButIgual(_ sender: UIButton) {
    
        num2 = Int(String(labelNumero.text!))!
        
        var resultado = CMatematicas.Sumar(n1: num1, n2: num2)
        labelNumero.text = String(resultado)
        
        
      /*  var resultado:Int
        resultado = num1 + num2
        labelNumero.text = String(resultado)
       */
        
    }
    
    
}


