//
//  CMatematicas.swift
//  appSwiftIOS_1
//
//  Created by Usuario invitado on 15/11/22.
//

import Foundation

class CMatematicas
{
    
    static func Sumar(n1:Int, n2:Int) ->Int
    {
        
        let result = n1 + n2
        return result
        
    }
    static func Sumar(n1:Double,n2:Double) -> Double
    {
        
        let result = n1 + n2
        return result
        
    }
    
    //AGREGAR LAS OPERACIONES ARITMETICAS BASICAS
    //AGREGAR LOS METODOS RESUELTOS EN LA APP, DE CONSOLA
    // FACTORIAL, PARES, SERIE E
    
}
