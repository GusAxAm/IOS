//
//  appConjuntosIOSApp.swift
//  appConjuntosIOS
//
//  Created by Guest User on 22/11/22.
//

import SwiftUI

@main
struct appConjuntosIOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
