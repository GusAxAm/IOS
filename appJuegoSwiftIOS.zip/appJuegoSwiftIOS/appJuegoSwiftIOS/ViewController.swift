//
//  ViewController.swift
//  appJuegoSwiftIOS
//
//  Created by Usuario invitado on 24/11/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var Numero: UITextField!
    
    @IBOutlet weak var labelIntentos: UILabel!
 
    @IBOutlet weak var Mensaje: UILabel!
    
    var numRandom = 0
    var intento = 0
    
    func inicializar()
    {
        numRandom = Int.random(in: 0...9)
        Numero.text = ""
        intento = 3
        
        labelIntentos.text = String(intento)
        Mensaje.text = "SELECCIONAR UN NUMERO DE 0-9"
        //let color = UIColor(red: 1.0, green: 1.0, blue: 0.0, alpha: 1.0)
        
        self.view.backgroundColor = #colorLiteral(red: 0.9098039269, green: 0.4784313738, blue: 0.6431372762, alpha: 1)
        
    }
    @IBAction func ButJugar(_ sender: UIButton) {
        
        if Numero.text == String(numRandom)
        {
            Mensaje.text = "GANASTE, FELICIDADES"
            self.view.backgroundColor = #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1)
        }
        else
        {
        if intento == 1
            {
            Mensaje.text = "FALLASTE, VUELVE A INTENTARLO"
            self.view.backgroundColor = #colorLiteral(red: 0.7450980544, green: 0.1568627506, blue: 0.07450980693, alpha: 1)
            alerta()
           //self.viewDidLoad()
            }
            else
            {
                intento -= 1
                labelIntentos.text = String(intento)
                Mensaje.text = "Vuelve a intentarlo"
                Numero.text = ""
            }
            
        }
    }
    func alerta()
    {
        
        let alerta = UIAlertController(title: "Mensaje", message: "Intentalo otra vez", preferredStyle: .alert)
        
        let jugarOtraVez = UIAlertAction(title: "Juega chiquillo", style: .default)
        
        alerta.addAction(jugarOtraVez)
        self.present(alerta,animated: true, completion: nil)
        
        
    }
    
    @IBAction func butOtro(_ sender: UIButton) {
        
       // inicializar()
        
        self.viewDidLoad()
        
        
    }
    @IBAction func ButSalir(_ sender: UIButton) {
        
        UIControl().sendAction(#selector(NSXPCConnection.suspend),to: UIApplication.shared,for: nil)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
     
        inicializar()
        
       
    }

    


}

