//
//  Vista.h
//  appGraficosOSX_1
//
//  Created by Usuario invitado on 17/10/22.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface Vista : NSView
-(NSPoint) randomPoint;


@end

NS_ASSUME_NONNULL_END
