//
//  Vista.m
//  appGraficosOSX_1
//
//  Created by Usuario invitado on 17/10/22.
//

#import "Vista.h"

@implementation Vista
-(NSPoint) randomPoint
{
    NSPoint result;
    NSRect r = [self bounds];
    result.x = r.origin.x + random() % (int)r.size.width;
    result.y = r.origin.y + random() % (int)r.size.height;
    return result;
    
    
    
}
- (void)drawRect:(NSRect)dirtyRect {
    
    [super drawRect:dirtyRect];
    
    NSRect rectangulo = [self bounds];
    
    //[[NSColor blueColor] set];
    [[NSColor colorWithDeviceRed:0.1f green:0.875f blue:0.875f alpha:1.0f]set];

    //NSColor *color= [NSColor colorWithCalibratedRed:1.0 green:0 blue:0 alpha:1.0];
    //[color set];
    
  [NSBezierPath fillRect:rectangulo];
    
    [[NSColor whiteColor]set];
    
    NSBezierPath *path = [[NSBezierPath alloc]init];
    [path setLineWidth:3.0];
    
    srand((unsigned) time(NULL));
    
    NSPoint punto =[self randomPoint];
    [path moveToPoint:punto];
    for(int i = 0; i < 10; i++)
    {
        punto =[self randomPoint];
        [path lineToPoint:punto];
    }
    [path stroke];
    [path fill];
    // Drawing code here.
}

@end
