//
//  AppDelegate.h
//  appGraficosOSX_1
//
//  Created by Usuario invitado on 17/10/22.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

