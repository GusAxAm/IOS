//
//  main.swift
//  appSwift1
//
//  Created by Usuario invitado on 07/11/22.
//

import Foundation

//print("Hello, World!")

var n1 = 100
var n2 = 50
var resultado = n1 ^ n2

print ("n1 = \(n1) ^ n2 = \(n2) =",resultado)

let binario = String(resultado,radix: 2)
print("\(resultado) en binario = \(binario) \n")

print("\(n1) & \(n2) = ",n1 & n2)
print("\(n1) | \(n2) = ",n1 | n2)

var val1 = 255;
let binResul = String(val1,radix: 2);
print("\t Numero : \(val1) = \(binResul)")


let octResul = String(val1,radix: 8);
print("\t Numero : \(val1) = \(octResul)")


let hexaResul = String(val1,radix: 16);
print("\t Numero : \(val1) = \(hexaResul)")

let valBinario = "1010110"
let numBinario = String(Int(valBinario,radix: 2)! ,radix: 16)
print("\(valBinario) = \(numBinario) en hexadecimal")

let valHexa = "face"
let valBinario2 = String(Int(valHexa,radix: 16)! ,radix: 2)
print("\(valHexa) = \(valBinario2) en binario")

var valHexaInt = Int(valHexa,radix:16)!
valHexaInt <<= 2
var valBinarioInt = String(valHexaInt,radix:2)
print("\(valHexaInt) = \(valBinarioInt) en binario")

//RANGOS

print("RANGO CERRADO")
let rangoCerrado = ...5
print(rangoCerrado.contains(7))
print(rangoCerrado.contains(4))
print(rangoCerrado.contains(-100000))

print("RANGO ABIERTO")
let rangoAbierto = 5...
print(rangoAbierto.contains(7))
print(rangoAbierto.contains(4))
print(rangoAbierto.contains(1000000))
print(rangoAbierto.contains(Int.max))

//let numInt64 : UInt64 = 9223372036854775807
print(rangoAbierto.contains(147483646))

var cadena = "TEC LAGUNA"
var cadResultado:String=""
let caracteres = Array(cadena)
for i in 0..<caracteres.count
{
    let c = String(caracteres[i])
    cadResultado += c.uppercased()
    print(cadResultado)
}

print(cadResultado)

func mayorMenor(array: [Int]) -> (mayor:Int,menor:Int)
{
    var mayor = array[0]
    var menor = array[0]
    for val in array[1..<array.count]
    {
        if val < menor
        {
            menor = val
        }
        else if val > mayor{
            mayor = val
        }
    }
    return (mayor,menor)
}
let funcion = mayorMenor(array: [25,60,12,37,45])

print("Valor Mayor : \(funcion.mayor), Valor Menor : \(funcion.menor)")
print(funcion)
