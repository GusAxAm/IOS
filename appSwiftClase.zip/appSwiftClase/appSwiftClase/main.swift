//
//  main.swift
//  appSwiftClase
//
//  Created by Usuario invitado on 11/11/22.
//

import Foundation

//print("Hello, World!")

class Clase
{
    var a:Int
    var b:Int
    static var c: Int = 0
    
    init(a: Int, b: Int)
    {
        self.a = a
        self.b = b
        
        Clase.c += 1
        
    }
    func imprimir()
    {
        print("Valor a = \(a)")
        print("Valor de b: ",b)
        print("Valor de c = \(Clase.c)")
        
        
    }
}

let objeto = Clase(a: 100, b: 200)
objeto.imprimir()

let aux = objeto
//Unmanaged.passUnretained(objeto).toOpaque()
print("Dirccion de objeto: \(Unmanaged.passUnretained(objeto).toOpaque())")
print("Dirccion de aux: \(Unmanaged.passUnretained(aux).toOpaque())")

print("Valor de  a = \(objeto.a)")

aux.imprimir()          


