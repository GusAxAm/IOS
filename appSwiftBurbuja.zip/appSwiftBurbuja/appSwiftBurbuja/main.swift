//
//  main.swift
//  appSwiftBurbuja
//
//  Created by Usuario invitado on 11/11/22.
//

import Foundation

//print("Hello, World!")

func burbuja(vec: Array<Int>) ->Array<Int>
{
    var vecAux : [Int] = [] //arreglo vacio
    if vec.isEmpty
    {
        return vecAux
    }
    
    vecAux = vec
    //var i = 2
    for _ in 0 ..< vecAux.count-1
    {
        for j in 0..<vecAux.count-1
        {
            var aux = 0
            if(vecAux[j] > vecAux[j+1])
            {
                aux = vecAux[j]
                vecAux[j] = vecAux[j+1]
                vecAux[j+1] = aux
            }
        }
    }
    return vecAux
}

