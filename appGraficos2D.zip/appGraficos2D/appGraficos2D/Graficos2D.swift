//
//  Graficos2D.swift
//  appGraficos2D
//
//  Created by Usuario invitado on 28/11/22.
//

import UIKit

class Graficos2D: UIView {

    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
        let canvas =  UIGraphicsGetCurrentContext()
        
        canvas?.setLineWidth(3.0)
        //canvas?.setStrokeColor(UIColor.blue.cgColor)
        //canvas?.setStrokeColor(#colorLiteral(red: 1.0, green: 0.0, blue: 1.0,alpha:1.0))
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let components: [CGFloat] = [CGFloat(Float.random(in: 0.0..<1.0)),
                                     CGFloat(drand48()),0.0,1.0]
        
        //INVESTIGAR EL TIPO drand48
        let color = CGColor(colorSpace: colorSpace, components: components)
        
        canvas?.setStrokeColor(color!)
        //linea
        canvas?.move(to: CGPoint(x: 0, y: 0))
        canvas?.addLine(to: CGPoint(x: rect.width, y: rect.height))
        
        canvas?.strokePath()
        
        let rectangulo = CGRect(x: rect.width/2-20, y: rect.width/2-80, width: rect.width/2, height: rect.width/2-80)
        canvas?.addRect(rectangulo)
        canvas?.strokePath()
        canvas?.setFillColor(UIColor.magenta.cgColor)
        canvas?.fill(rectangulo)
        //GRADIENTES
      /*  let position : [CGFloat] = [0.0,0.25,0.75]
        
        let colores = [UIColor.blue.cgColor,UIColor.green.cgColor,UIColor.blue.cgColor,UIColor.green.cgColor]
        
        let colorSpace1 = CGColorSpaceCreateDeviceRGB()
        let gradiente = CGGradient(colorsSpace: colorSpace1, colors: colores as CFArray, locations: position)
        
        var startPoint = CGPoint()
        var endPoint = CGPoint()
        startPoint.x = 0.0
        startPoint.y = 0.0
        endPoint.x = rect.width
        endPoint.y = rect.height
        
        canvas?.drawLinearGradient(gradiente!, start: startPoint, end: endPoint, options: .drawsBeforeStartLocation)
        
        */
        
        //GRADIENTE RADIAL
        let locationR : [CGFloat] = [0.0,0.5,1.0]
        let coloresR = [UIColor.red.cgColor,UIColor.brown.cgColor,UIColor.cyan.cgColor,UIColor.purple.cgColor]
        let colorSpaceR = CGColorSpaceCreateDeviceRGB()
        let gradienteR = CGGradient(colorsSpace: colorSpaceR, colors: coloresR as CFArray, locations: locationR)
        var startPointR = CGPoint()
        var endPointR = CGPoint()
        startPointR.x = 100
        startPointR.y = rect.height/2.0
        endPointR.x = 200
        endPointR.y = 400
        // SE REQUIEREN DOS RADIOS
        let radio1: CGFloat = 60.0
        let radio2: CGFloat = 90.0
        
        canvas?.drawRadialGradient(gradienteR!, startCenter: startPointR, startRadius: radio1, endCenter: endPointR, endRadius: radio2, options: [])
        //CURVAS DE BEZIER
        
        canvas?.move(to: CGPoint(x:0,y:0))
        canvas?.addCurve(to: CGPoint(x:rect.width-10,y:400), control1: CGPoint(x:20,y:200), control2: CGPoint(x:rect.width-50,y:300))
       
        canvas?.strokePath()
        
        
    }
    

}
