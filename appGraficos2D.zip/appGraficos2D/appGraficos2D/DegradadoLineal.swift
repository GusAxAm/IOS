//
//  DegradadoLineal.swift
//  appGraficos2D
//
//  Created by Usuario invitado on 29/11/22.
//

import UIKit

class DegradadoLineal: UIView {

    
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        
        // Drawing code
        
        
        let canvas =  UIGraphicsGetCurrentContext()
        //GRADIENTES
        //let position : [CGFloat] = [0.0,0.25,0.75]
        let position : [CGFloat] = [0.60,0.34,0.58]
        let colores = [UIColor.blue.cgColor,UIColor.green.cgColor,UIColor.blue.cgColor,UIColor.green.cgColor]
        
        let colorSpace1 = CGColorSpaceCreateDeviceRGB()
        let gradiente = CGGradient(colorsSpace: colorSpace1, colors: colores as CFArray, locations: position)
        
        var startPoint = CGPoint()
        var endPoint = CGPoint()
        startPoint.x = 0.0
        startPoint.y = 0.0
        endPoint.x = rect.width
        endPoint.y = rect.height
        
        canvas?.drawLinearGradient(gradiente!, start: startPoint, end: endPoint, options: .drawsBeforeStartLocation)
        
        
        
        
        
        
    }
    

   
    
   
    
    
    
}
