//
//  SceneDelegate.h
//  AplicacionGraficos
//
//  Created by Guest User on 01/11/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

