//
//  Graficos.m
//  AplicacionGraficos
//
//  Created by Guest User on 01/11/22.
//

#import "Graficos.h"

@implementation Graficos


/* Only override drawRect: if you perform custom drawing.
 An empty implementation adversely affects performance during animation.
 */
- (void)drawRect:(CGRect)rect {
    
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetLineWidth(context, 3.0);
    
    CGContextSetStrokeColorWithColor(context, [UIColor blueColor].CGColor);
    //Dibujar Linea
    CGContextMoveToPoint(context, x1, x2);
    CGContextAddLineToPoint(context, x1, x2);
    
    CGContextStrokePath(context);
    
    
    //
   /*
    CGContextMoveToPoint(context, 100, 100);
    CGContextAddLineToPoint(context, 150, 150);
    CGContextAddLineToPoint(context, 100, 200);
    CGContextAddLineToPoint(context, 50, 150);
    CGContextAddLineToPoint(context, 100, 100);
    
    CGContextStrokePath(context);
    CGContextSetFillColorWithColor(context, [UIColor orangeColor].CGColor);
    CGContextFillPath(context);
    //Rectangulo
    
    CGRect rectangulo = CGRectMake(100, 250, 200, 150);
    CGContextAddRect(context, rectangulo);
    CGContextStrokePath(context);
    CGContextSetFillColorWithColor(context, [UIColor purpleColor].CGColor);
    CGContextFillRect(context, rectangulo);
    */

    
}

-(void)Linea:(UIButton *)sender{
  
    [self setNeedsDisplay];
    
}

@end
