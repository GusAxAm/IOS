//
//  AppDelegate.h
//  AplicacionGraficos
//
//  Created by Guest User on 01/11/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

