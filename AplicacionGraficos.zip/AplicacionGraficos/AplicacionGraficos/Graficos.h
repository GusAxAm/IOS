//
//  Graficos.h
//  AplicacionGraficos
//
//  Created by Guest User on 01/11/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Graficos : UIView
{
    int x1;
    int y1;
    int x2;
    int y2;
}
@property (weak, nonatomic) IBOutlet UITextField *X1;
@property (weak, nonatomic) IBOutlet UITextField *X2;
@property (weak, nonatomic) IBOutlet UITextField *Y1;
@property (weak, nonatomic) IBOutlet UITextField *Y2;
- (IBAction)Linea:(UIButton *)sender;

@end

NS_ASSUME_NONNULL_END
